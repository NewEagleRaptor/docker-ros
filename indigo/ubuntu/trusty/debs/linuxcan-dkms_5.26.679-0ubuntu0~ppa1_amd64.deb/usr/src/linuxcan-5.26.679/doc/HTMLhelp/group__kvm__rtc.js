var group__kvm__rtc =
[
    [ "kvmDeviceGetRTC", "group__kvm__rtc.html#gaed6bdf7015e147fcdfee5f776139795b", null ],
    [ "kvmDeviceSetRTC", "group__kvm__rtc.html#ga0545d8d9c2782728d263ed67cbc0efac", null ]
];