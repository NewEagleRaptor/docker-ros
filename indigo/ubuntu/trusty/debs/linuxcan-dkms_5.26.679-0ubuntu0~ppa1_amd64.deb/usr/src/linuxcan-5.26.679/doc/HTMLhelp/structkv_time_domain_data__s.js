var structkv_time_domain_data__s =
[
    [ "nMagiSyncedMembers", "structkv_time_domain_data__s.html#aadd2929832bd903c78ddf59c21feea05", null ],
    [ "nMagiSyncGroups", "structkv_time_domain_data__s.html#ab8dca255d18320cb7bd22b0448d78fb7", null ],
    [ "nNonMagiSyncCards", "structkv_time_domain_data__s.html#af00948e6feb807b210c69fd5945e7068", null ],
    [ "nNonMagiSyncedMembers", "structkv_time_domain_data__s.html#a9cc0826be3a3477969cc862737e0f334", null ]
];