var annotated_dup =
[
    [ "canBusStatistics_s", "structcan_bus_statistics__s.html", "structcan_bus_statistics__s" ],
    [ "canNotifyData", "structcan_notify_data.html", "structcan_notify_data" ],
    [ "canUserIoPortData", "structcan_user_io_port_data.html", "structcan_user_io_port_data" ],
    [ "KvaDbProtocolProperties", "struct_kva_db_protocol_properties.html", "struct_kva_db_protocol_properties" ],
    [ "kvmLogEventEx", "structkvm_log_event_ex.html", "structkvm_log_event_ex" ],
    [ "kvmLogMsgEx", "structkvm_log_msg_ex.html", "structkvm_log_msg_ex" ],
    [ "kvmLogRtcClockEx", "structkvm_log_rtc_clock_ex.html", "structkvm_log_rtc_clock_ex" ],
    [ "kvmLogTriggerEx", "structkvm_log_trigger_ex.html", "structkvm_log_trigger_ex" ],
    [ "kvmLogVersionEx", "structkvm_log_version_ex.html", "structkvm_log_version_ex" ],
    [ "KvParseHandle", "struct_kv_parse_handle.html", "struct_kv_parse_handle" ],
    [ "kvTimeDomainData_s", "structkv_time_domain_data__s.html", "structkv_time_domain_data__s" ],
    [ "LinMessageInfo", "struct_lin_message_info.html", "struct_lin_message_info" ],
    [ "tag_token", "structtag__token.html", "structtag__token" ]
];