var searchData=
[
  ['database_20api_20_28kvadblib_29',['Database API (kvaDbLib)',['../page_kvadblib.html',1,'']]]
];
