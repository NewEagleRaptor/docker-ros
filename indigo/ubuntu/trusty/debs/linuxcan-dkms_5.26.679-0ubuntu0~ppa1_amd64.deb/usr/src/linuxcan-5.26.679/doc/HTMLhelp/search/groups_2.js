var searchData=
[
  ['databases',['Databases',['../group__kvadb__database.html',1,'']]],
  ['database',['Database',['../group__kvlc__database.html',1,'']]],
  ['device_20connection',['Device Connection',['../group__kvm__connection.html',1,'']]],
  ['databases',['Databases',['../group__kvm__database.html',1,'']]],
  ['disk_20operations',['Disk Operations',['../group__kvm__disk__operations.html',1,'']]]
];
