var group__kvm__files =
[
    [ "kvmKmeCloseFile", "group__kvm__files.html#ga63e7277573c63cec87c936635fc7d95c", null ],
    [ "kvmKmeCountEvents", "group__kvm__files.html#ga689dc55a54efa5ba651a0f76422926ce", null ],
    [ "kvmKmeCreateFile", "group__kvm__files.html#gae309647756ed973d31b8b1b01c1fa10d", null ],
    [ "kvmKmeOpenFile", "group__kvm__files.html#ga006f92f4fb82c0aad0351eda067b5d30", null ],
    [ "kvmKmeReadEvent", "group__kvm__files.html#ga2127d572c0e8cc83efaf6d8a6fe63f79", null ],
    [ "kvmKmeScanFileType", "group__kvm__files.html#ga26c980e4cdd291958cc540b55d1bf481", null ],
    [ "kvmKmeWriteEvent", "group__kvm__files.html#ga4cb62b5a18c44a740b01f59548f5d2ff", null ]
];