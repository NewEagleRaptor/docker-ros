var group__kvm__disk__operations =
[
    [ "kvmDeviceFormatDisk", "group__kvm__disk__operations.html#gaea656874540da1c4551dbac178052647", null ],
    [ "kvmKmfValidate", "group__kvm__disk__operations.html#gae3520ee83055783a046db21c8feae908", null ]
];